<?php
header('Location: saran/saran.php');
?>