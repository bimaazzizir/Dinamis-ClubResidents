<?php
header('Location: .php');
?>